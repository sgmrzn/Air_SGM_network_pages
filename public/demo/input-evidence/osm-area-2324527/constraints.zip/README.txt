Текущая полная выборка выбранного векторного слоя по прямоугольнику территории.
Измерения ограничены границей поселения. Сведения о методе и качестве — в passport.json.
Это не архив сохранённого расчёта. Растры и метеоряды в комплект не входят.
content_sha256 = SHA256 JSON объекта с ключами version, layer, boundary, features, source_provenance.
Первые четыре значения берутся из objects.geojson, source_provenance — из его summary.
Сериализация Python json.dumps: ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False, default=str; UTF-8.
manifest.json содержит SHA256 фактических байтов остальных файлов комплекта.
